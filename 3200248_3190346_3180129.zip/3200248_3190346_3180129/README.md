# ΚΑΤΑΝΕΜΗΜΕΝΑ ΣΥΣΤΗΜΑΤΑ

## Contributors
* Ελευθερία Ντούλια Α.Μ.: 3180129
* Πελαγία Ροδίτη Α.Μ.: 3190346
* Ηλίας Θεοφάνης Γραββάνης Α.Μ.: 3200248


### SETUP INSTRUCTIONS
* Run Broker as a three different server inside the broker_app folder (to take correct paths insted in Node.java change paths in nodePath and brokerPath)
* Run android app inside andoid_app folder there need to build and run project
    * You will find Consumer and Publisher inside.
    * The Topic_Activity for messaging (chat).
    * The First_Activity for subject selection. 
    * The Main_Activity for login page.

