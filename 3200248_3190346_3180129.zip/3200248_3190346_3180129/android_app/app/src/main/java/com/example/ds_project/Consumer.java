package com.example.ds_project;

import android.os.Environment;
import android.widget.TextView;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.concurrent.CountDownLatch;

class Message {
    int type;
    String name;
    String content;

    Message(int type, String name, String content) {
        this.type = type;
        this.name = name;
        this.content = content;
    }

}

// subscriber service
public class Consumer extends Node implements Runnable {
    ProfileName subscriber;
    static String username;
    private DataInputStream input;
    private DataOutputStream output;
    private Socket client;
    private static String chatServer = "192.168.1.201"; // "127.0.0.1"

    public Consumer(String username) {
        this.username = username;
    }

    public Consumer(ProfileName subscriber) {
        this.subscriber = subscriber;
    }

    @Override
    public void run() {
    }

    void disconnect(String topic) {
        // unsubscribe
    }

    void register(String topic) {
        // subscribe
    }

    void showConversationData(String topic, Value val) {

    }

    // TODO CONNECT TO FIRST RANDOM BROKER AND BROKER SEND BROKERS LIST WITH TOPICS
    // AND SELECT THE RIGHT BROKER TO CONNECT
    public void start(String subject) throws UnknownHostException, IOException, InterruptedException {

        System.out.println("In start");
        client = new Socket(InetAddress.getByName(chatServer), 1234); // start()
        input = new DataInputStream(client.getInputStream());
        output = new DataOutputStream(client.getOutputStream());
        System.out.println("Finish start");

    }

    public synchronized LinkedList<Message> pull(String subject) throws IOException, InterruptedException { // void
        // readMessage thread

        LinkedList<Message> messages = new LinkedList<>();
        output.writeUTF("Subscriber");
        output.writeUTF(subject);
        output.writeUTF("subscriber");

        System.out.println("Pull");
        final CountDownLatch latch = new CountDownLatch(1);
        Thread readMessage = new Thread(new Runnable() {
            @Override
            public void run() {
                System.out.println("In thread");

                try {
                    output.writeUTF("BrokersList");
                } catch (IOException e) {
                    e.printStackTrace();
                }
                while (true) { // runs when refresh button is pressed
                    try {
                        int type = input.readInt();
                        System.out.println(type);
                        if (type == 1) {
                            // while(true){
                            System.out.println("------>DOWNLOAD STARTED");
                            String profileName = input.readUTF();
                            String fileName = input.readUTF();

                            int fileContentLength = input.readInt();
                            System.out.println("------>FILE_CONTENT_LENGTH " + fileContentLength);
                            if (fileContentLength > 0) {
                                byte[] fileContentBytes = new byte[fileContentLength];
                                input.readFully(fileContentBytes, 0, fileContentBytes.length);
                                File directory = new File(String.valueOf(Environment.getExternalStoragePublicDirectory(
                                        Environment.DIRECTORY_DOWNLOADS + "/downloaded_videos")));
                                if (!directory.exists())
                                    directory.mkdir();
                                System.out.println("------>VIDEO IS ABOUT TO BE SAVED");
                                File document = new File(Environment.getExternalStoragePublicDirectory(
                                        Environment.DIRECTORY_DOWNLOADS + "/downloaded_videos"), fileName);
                                if (document.exists()) {
                                    document.delete();
                                }
                                try {
                                    FileOutputStream out = new FileOutputStream(document.getPath());
                                    System.out.println("------>VIDEO IS ABOUT TO BE DOWNLOADED");
                                    out.write(fileContentBytes);
                                    out.close();
                                    System.out.println("------>FILE OK");
                                    messages.add(new Message(1, profileName, document.getPath()));

                                } catch (IOException error) {

                                    error.printStackTrace();
                                    return;
                                }

                            }
                        } else if (type == 2) {
                            String profileName = input.readUTF();
                            messages.add(new Message(2, profileName, input.readUTF()));
                        }
                        latch.countDown();
                    } catch (IOException e) {
                        System.out.println("----->Exception");
                        e.printStackTrace();
                        break;
                    }
                }
            }
        });
        readMessage.start();
        latch.await();
        return messages;
    }

}
