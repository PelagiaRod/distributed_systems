package com.example.ds_project;


import java.io.File;
import java.util.*;

public class Node {
    public ArrayList<Topic> topics = new ArrayList<>();
    private static File currDirectory = new File(new File("").getAbsolutePath());
    private static String topicsPath = currDirectory + "\\data\\topics.txt";
    private static String brokersPath = currDirectory + "\\data\\brokers.txt";

    // TODO: READ LIST FROM TXT
    public void loadTopics() {

        ArrayList<String> topicsLines = FileHelper.readFile(topicsPath);

        for (String line : topicsLines) {
            topics.add(new Topic(line));
        }

    }

    public ArrayList<Topic> getTopics() {
        return topics;
    }

    public Node() {

    }

}