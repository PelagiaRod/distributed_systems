package com.example.ds_project;

// import javafx.util.Pair;
import android.net.Uri;
import android.os.Build;

import androidx.annotation.RequiresApi;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.HashMap;

public class Publisher extends Node implements Runnable {
    String username;
    ProfileName profileName;
    private static Boolean flag = true;
    private HashMap<ProfileName, AbstractMap.SimpleEntry<String, Value>> queueOfTopics;
    private DataInputStream input;
    private DataOutputStream output;
    private Socket client;
    private static String chatServer = "192.168.1.53"; //
    private static File mediaDirectory = new File(new File("").getAbsolutePath() + "/data/media/");

    public Publisher(String username) {

        this.username = username;
    }

    public void start() throws UnknownHostException, IOException {
        if (!flag)
            disconnect();

        client = new Socket(InetAddress.getByName(chatServer), 1234); // "192.168.1.190"
        input = new DataInputStream(client.getInputStream());
        output = new DataOutputStream(client.getOutputStream());

    }

    public void disconnect() { // was private
        System.out.println("\nClosing connection");
        try {
            output.close();
            input.close();
            client.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @Override
    public void run() {
    }

    ArrayList<Value> generateChunks(MultimediaFile file) {
        Value value = new Value(file);
        ArrayList<Value> chunks = new ArrayList<>();
        return chunks;
    }

    void notifyBrokersNewMessage(String message) {

    }


    // synchronized method in order to avoid a race condition and
    // ALLOW only one thread to execute this block at any given time
    public synchronized void push(String subject, String type, String msg) {
        try {
            output.writeUTF(username);
            output.writeUTF(subject);
            output.writeUTF("publisher");

            // sendMessage thread
            Thread sendMessage = new Thread(new Runnable() {
                @RequiresApi(api = Build.VERSION_CODES.O)
                @Override
                public void run() {

                    switch (type) {
                        case "1":
                            try {
                                System.out.println("----->msg: " + msg);
                                output.writeUTF("1");
                                upload(msg);
                            } catch (IOException e) {
                                e.printStackTrace();
                            }

                            break;
                        case "2":

                            try {
                                // write on the output stream
                                output.writeUTF("2");
                                output.writeUTF(username + "#" + msg);
                                break;
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                            break;
                        case "exit":
                            break;
                        default:
                            System.out.println("You must select either 1 or 2");
                            System.out.println("Or say 'exit' to close connection");
                            break;
                    }
                    // }
                }

            });

            sendMessage.start();

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void upload(String file_to_upload) {
        System.out.println("file_to_upload----> " + file_to_upload);
        try {

            FileInputStream fileInputStream = new FileInputStream(file_to_upload); // (mediaDirectory + "\\" + fileName)
            File file = new File(file_to_upload);

            Path path = Paths.get(file_to_upload);

            // call getFileName() and get FileName path object
            String fileName = path.getFileName().toString();
            // System.out.println("----->filename: "+ fileName);
            byte[] fileNameBytes = fileName.getBytes(); // StandardCharsets.UTF_8

            int count;
            output.writeInt(fileNameBytes.length);
            output.write(fileNameBytes);

            byte[] fileContentBytes = new byte[(int) file.length()];
            output.writeInt(fileContentBytes.length);

            // break in chunks and send file
            while ((count = fileInputStream.read(fileContentBytes)) > 0) {
                output.write(fileContentBytes, 0, count);
            }
            output.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}