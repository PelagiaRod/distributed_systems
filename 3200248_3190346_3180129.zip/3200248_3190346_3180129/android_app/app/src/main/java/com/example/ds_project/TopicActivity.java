package com.example.ds_project;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.LinkedList;
import java.util.List;

public class TopicActivity extends AppCompatActivity {

    private Button btn;
    private VideoView videoView;
    private static final String VIDEO_DIRECTORY = "/Images";
    private int GALLERY = 1, CAMERA = 2;

    EditText msg;
    Publisher publisher;
    String subject;
    String username;
    Consumer consumer;
    TextView textView;
    TextView inputmessage;
    Uri selectedImage;
    private String selectedPath;
    LinkedList<Message> messages = new LinkedList<>();
    ListView lv;
    MyListAdaper adapter;
    MediaController media;
    private static final int SELECT_VIDEO = 3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_topic);
        lv = (ListView) findViewById(R.id.messagesList);
        adapter = new TopicActivity.MyListAdaper(this, R.layout.activity_item, messages);
        lv.setAdapter(adapter);
        Intent myIntent = getIntent();
        subject = myIntent.getStringExtra(First_Activity.EXTRA_SUBJECT);
        username = myIntent.getStringExtra(First_Activity.EXTRA_USERNAME);
        // usermessage = myIntent.getStringExtra(this.EXTRA_INPUTMESSAGE);
        media = new MediaController(this);
        publisher = new Publisher(username);
        consumer = new Consumer(username);

        textView = (TextView) findViewById(R.id.textView);
        textView.setText(subject);

        msg = (EditText) findViewById(R.id.writeMessage);

        ImageButton imgMsg = (ImageButton) findViewById(R.id.get_file);
        imgMsg.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                Intent intent = new Intent(Intent.ACTION_PICK);
                intent.setType("video/*");

                startActivityForResult(Intent.createChooser(intent, "Select a Video "), SELECT_VIDEO);

            }

        });

        ImageButton textMsg = (ImageButton) findViewById(R.id.sendMsg);
        textMsg.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                // This is the async task
                PublisherHandle publisherHanle = new PublisherHandle();
                publisherHanle.execute();
            }
        });

        ImageButton refresh = (ImageButton) findViewById(R.id.refresh);
        refresh.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ConsumerHandle consumerHandle = new ConsumerHandle();
                consumerHandle.execute();
            }
        });
    }

    private class PublisherHandle extends AsyncTask<Void, String, String> {
        ProgressDialog progressDialog;

        public PublisherHandle() {
        }

        @Override
        protected String doInBackground(Void... args) {
            String message = msg.getText().toString();

            try {
                publisher.start();
            } catch (IOException e) {
                e.printStackTrace();
            }

            publisher.push(subject, "2", message);
            return message;
        }

        @Override
        protected void onPreExecute() {
            progressDialog = ProgressDialog.show(TopicActivity.this,
                    "Please wait...",
                    "Connecting to server...");
        }

        @Override
        protected void onPostExecute(String result) {
            progressDialog.dismiss();
        }

        @Override
        protected void onProgressUpdate(String... values) {
            Toast.makeText(TopicActivity.this, "Progress: " + values[0], Toast.LENGTH_LONG).show();
        }
    }

    private class ConsumerHandle extends AsyncTask<Void, String, LinkedList<Message>> {
        ProgressDialog progressDialog;

        public ConsumerHandle() {
        }

        @Override
        protected LinkedList<Message> doInBackground(Void... args) {
            try {
                consumer.start(subject);
            } catch (IOException | InterruptedException e) {
                e.printStackTrace();
            }

            try {
                messages = consumer.pull(subject);
            } catch (IOException | InterruptedException e) {
                e.printStackTrace();
            }
            return messages;
        }

        @Override
        protected void onPreExecute() {
            progressDialog = ProgressDialog.show(TopicActivity.this,
                    "Please wait...",
                    "Connecting to server...");
        }

        @Override
        protected void onPostExecute(LinkedList<Message> result) {
            // This runs on the UI thread
            // execution of result of Long time consuming operation
            progressDialog.dismiss();

            String message = "\n";
            System.out.println("messages notify" + result.size());
            for (Message res : result) {
                message = message + res.name + " : " + res.content + "\n";
            }
            adapter.mObjects.clear();
            adapter.mObjects.addAll(result);
            // fire the event
            adapter.notifyDataSetChanged();
            System.out.println("messages notify" + result.size());

            Log.d("MY_TAG", "TEST");
        }

        @Override
        protected void onProgressUpdate(String... values) {
            // UI thread
            Toast.makeText(TopicActivity.this, "Progress: " + values[0], Toast.LENGTH_LONG).show();
        }
    }

    private class MyListAdaper extends ArrayAdapter<Message> {
        private int layout;
        private List<Message> mObjects;

        private MyListAdaper(Context context, int resource, List<Message> objects) {
            super(context, resource, objects);
            mObjects = objects;
            layout = resource;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            TopicActivity.ViewHolder mainViewholder = null;
            if (convertView == null) {
                LayoutInflater inflater = LayoutInflater.from(getContext());
                convertView = inflater.inflate(layout, parent, false);
                TopicActivity.ViewHolder viewHolder = new TopicActivity.ViewHolder();
                viewHolder.video = (VideoView) convertView.findViewById(R.id.messageVideo);
                viewHolder.textMessage = (TextView) convertView.findViewById(R.id.messageText);
                convertView.setTag(viewHolder);
            }
            mainViewholder = (TopicActivity.ViewHolder) convertView.getTag();
            Message item = getItem(position);
            if (item.type == 1) {
                System.out.println("item: " + item.name + " " + item.content);
                mainViewholder.textMessage.setText(item.name + " : ");
                mainViewholder.video.setVideoPath(item.content);
                mainViewholder.video.setVisibility(View.VISIBLE);

                mainViewholder.video.setMediaController(media);
                media.setAnchorView(mainViewholder.video);
            } else if (item.type == 2) {
                mainViewholder.textMessage.setText(item.name + " : " + item.content);
                mainViewholder.video.setVisibility(View.INVISIBLE);

            }
            return convertView;
        }
    }

    public class ViewHolder {
        VideoView video;
        TextView textMessage;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        System.out.println("IN ACTIVITY RESULT");
        if (resultCode == RESULT_OK) {

            System.out.println("SELECT_VIDEO");
            Uri selectedImageUri = data.getData();

            try {
                selectedPath = PathUtil.getPath(this, selectedImageUri);
            } catch (URISyntaxException e) {
                e.printStackTrace();
            }
            UploadVideo uploadVideo = new UploadVideo();
            uploadVideo.execute();

        }

    }

    private class UploadVideo extends AsyncTask<Void, String, String> {
        ProgressDialog progressDialog;

        public UploadVideo() {
        }

        @Override
        protected String doInBackground(Void... args) {

            try {
                publisher.start();
            } catch (IOException e) {
                e.printStackTrace();
            }

            publisher.push(subject, "1", selectedPath);
            return selectedPath;
        }

        @Override
        protected void onPreExecute() {

            progressDialog = ProgressDialog.show(TopicActivity.this,
                    "Please wait...",
                    "Connecting to server...");
        }

        @Override
        protected void onPostExecute(String result) {
            progressDialog.dismiss();

        }

        @Override
        protected void onProgressUpdate(String... values) {
            Toast.makeText(TopicActivity.this, "Progress: " + values[0], Toast.LENGTH_LONG).show();
        }

    }

    public String getPath(Uri uri) {
        Cursor cursor = getContentResolver().query(uri, null, null, null, null);
        cursor.moveToFirst();
        String document_id = cursor.getString(0);
        System.out.println("------>Document_id: " + document_id);
        document_id = document_id.substring(document_id.lastIndexOf(":") + 1);
        cursor.close();

        cursor = getContentResolver().query(
                android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                null, MediaStore.Images.Media._ID + " = ? ", new String[] { document_id }, null);
        cursor.moveToFirst();
        @SuppressLint("Range")
        String path = cursor.getString(cursor.getColumnIndex(MediaStore.Video.Media.DATA));
        cursor.close();

        return path;
    }

}
