
public class Value {
    MultimediaFile multimediaFile;

    public Value() {
    }

    public Value(MultimediaFile multimediaFile) {
        this.multimediaFile = multimediaFile;
    }

    public MultimediaFile getMultimediaFile() {
        return multimediaFile;
    }

    public void setMultimediaFile(MultimediaFile multimediaFile) {
        this.multimediaFile = multimediaFile;
    }

}
